# Widget GMC Ratings

Storefront plugin for GMC customer ratings
